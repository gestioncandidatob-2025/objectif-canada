"use client";

import { useEffect, useState, Fragment } from "react";
import { apiFetch } from "../../lib/api";
import { useLangue } from "../../lib/langue";
import Pagination, { usePagination } from "../../components/Pagination";

type Tarif = {
  _id: string;
  service: string;
  regimes?: string[];
  prix?: number;
  dureeJours?: number;
  actif: boolean;
  dateFinNecessaire: boolean;
  remiseActive: boolean;
  regimeActif: boolean;
  montantNegociable: boolean;
};

// Libellés connus pour les services historiques ; tout nouveau service tapé
// par l'utilisateur est affiché tel quel (mis en forme automatiquement).
const LABEL_SERVICE: Record<string, string> = {
  tcf: "TCF",
  tcf_2mois: "TCF 2 mois",
  examen_blanc: "Examen blanc",
  tcf_special: "TCF SPECIAL",
};

function formaterNomService(service: string): string {
  if (LABEL_SERVICE[service]) return LABEL_SERVICE[service];
  return service
    .split(/[_\s]+/)
    .filter(Boolean)
    .map((mot) => mot.charAt(0).toUpperCase() + mot.slice(1))
    .join(" ");
}

type FormulaireTarif = {
  service: string;
  regimes: string[];
  prix: string;
  dureeJours: string;
  dateFinNecessaire: boolean;
  remiseActive: boolean;
  regimeActif: boolean;
  montantNegociable: boolean;
};

const formulaireVide: FormulaireTarif = {
  service: "",
  regimes: [""],
  prix: "",
  dureeJours: "",
  dateFinNecessaire: false,
  remiseActive: false,
  regimeActif: false,
  montantNegociable: false,
};

type OptionTarif =
  | "dateFinNecessaire"
  | "remiseActive"
  | "regimeActif"
  | "montantNegociable";

type BlocOptionsProps = {
  valeurs: Pick<FormulaireTarif, OptionTarif>;
  onChange: (champ: OptionTarif, valeur: boolean) => void;
  idPrefix: string;
};

type ListeRegimesProps = {
  regimes: string[];
  onChange: (regimes: string[]) => void;
};

export default function TarifsPage() {
  const [tarifs, setTarifs] = useState<Tarif[]>([]);
  const [chargement, setChargement] = useState(false);
  const [erreur, setErreur] = useState("");
  const [message, setMessage] = useState("");

  const [afficherFormulaire, setAfficherFormulaire] = useState(false);
  const [form, setForm] = useState<FormulaireTarif>(formulaireVide);
  const [envoiEnCours, setEnvoiEnCours] = useState(false);

  const [ligneEnEdition, setLigneEnEdition] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<FormulaireTarif & { actif: boolean }>({
    ...formulaireVide,
    actif: true,
  });
  const [enregistrementEnCours, setEnregistrementEnCours] = useState(false);
  const [suppressionEnCours, setSuppressionEnCours] = useState<string | null>(null);
  // « tr » et pas « t » : dans cette page, « t » désigne déjà une offre
  const { t: tr, locale } = useLangue();
  const pages = usePagination(tarifs, 15);

  async function chargerTarifs() {
    setChargement(true);
    setErreur("");
    const res = await apiFetch("/tarifs");
    if (res.ok) {
      setTarifs(await res.json());
    } else {
      setErreur(tr("tarifs.erreurChargement"));
    }
    setChargement(false);
  }

  useEffect(() => {
    chargerTarifs();
  }, []);

  async function handleCreer(e: React.FormEvent) {
    e.preventDefault();
    setErreur("");
    setMessage("");
    setEnvoiEnCours(true);

    const regimesNettoyes = form.regimes.map((r) => r.trim()).filter(Boolean);

    const res = await apiFetch("/tarifs", {
      method: "POST",
      body: JSON.stringify({
        service: form.service,
        regimes: form.regimeActif ? regimesNettoyes : undefined,
        prix: form.montantNegociable ? undefined : Number(form.prix),
        dureeJours: form.dateFinNecessaire ? undefined : Number(form.dureeJours),
        dateFinNecessaire: form.dateFinNecessaire,
        remiseActive: form.remiseActive,
        regimeActif: form.regimeActif,
        montantNegociable: form.montantNegociable,
      }),
    });

    if (!res.ok) {
      const data = await res.json();
      setErreur(Array.isArray(data.message) ? data.message.join(", ") : data.message);
      setEnvoiEnCours(false);
      return;
    }

    setMessage(tr("tarifs.offreCreee"));
    setForm(formulaireVide);
    setAfficherFormulaire(false);
    setEnvoiEnCours(false);
    chargerTarifs();
  }

  function ouvrirEdition(t: Tarif) {
    setLigneEnEdition(t._id);
    setEditForm({
      service: t.service,
      regimes: t.regimes && t.regimes.length > 0 ? t.regimes : [""],
      prix: t.prix !== undefined ? String(t.prix) : "",
      dureeJours: t.dureeJours !== undefined ? String(t.dureeJours) : "",
      dateFinNecessaire: t.dateFinNecessaire,
      remiseActive: t.remiseActive,
      regimeActif: t.regimeActif,
      montantNegociable: t.montantNegociable,
      actif: t.actif,
    });
  }

  async function enregistrerModification(id: string) {
    setEnregistrementEnCours(true);
    setErreur("");
    const regimesNettoyes = editForm.regimes.map((r) => r.trim()).filter(Boolean);

    const res = await apiFetch(`/tarifs/${id}`, {
      method: "PATCH",
      body: JSON.stringify({
        service: editForm.service,
        regimes: editForm.regimeActif ? regimesNettoyes : undefined,
        prix: editForm.montantNegociable ? undefined : Number(editForm.prix),
        dureeJours: editForm.dateFinNecessaire ? undefined : Number(editForm.dureeJours),
        actif: editForm.actif,
        dateFinNecessaire: editForm.dateFinNecessaire,
        remiseActive: editForm.remiseActive,
        regimeActif: editForm.regimeActif,
        montantNegociable: editForm.montantNegociable,
      }),
    });
    if (!res.ok) {
      const data = await res.json();
      setErreur(Array.isArray(data.message) ? data.message.join(", ") : data.message);
      setEnregistrementEnCours(false);
      return;
    }
    setLigneEnEdition(null);
    setEnregistrementEnCours(false);
    chargerTarifs();
  }

  async function supprimerTarif(t: Tarif) {
    const confirme = window.confirm(
      tr("tarifs.confirmerSuppression", { service: formaterNomService(t.service) }),
    );
    if (!confirme) return;

    setSuppressionEnCours(t._id);
    setErreur("");
    setMessage("");
    const res = await apiFetch(`/tarifs/${t._id}`, { method: "DELETE" });
    setSuppressionEnCours(null);

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      setErreur(Array.isArray(data.message) ? data.message.join(", ") : data.message);
      return;
    }

    // Le serveur indique s'il a supprimé l'offre ou s'il l'a désactivée
    setMessage(data.message ?? tr("tarifs.offreSupprimee"));
    chargerTarifs();
  }

  const champClass =
    "w-full rounded-lg border border-ink/15 px-3 py-2.5 text-ink outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20";
  const labelClass = "mb-1 block text-sm font-medium text-ink-soft";
  const checkboxLigne = "flex items-center gap-2 text-sm text-ink";

  const servicesExistants = Array.from(new Set(tarifs.map((t) => t.service)));

  function BlocOptions({ valeurs, onChange, idPrefix }: BlocOptionsProps) {
    return (
      <div className="space-y-2 rounded-lg border border-ink/10 bg-paper p-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft">
          {tr("tarifs.configFormulaire")}
        </p>
        <label className={checkboxLigne}>
          <input
            id={`${idPrefix}-regimeActif`}
            type="checkbox"
            checked={valeurs.regimeActif}
            onChange={(e) => onChange("regimeActif", e.target.checked)}
          />
          {tr("tarifs.optionRegime")}
        </label>
        <label className={checkboxLigne}>
          <input
            id={`${idPrefix}-dateFinNecessaire`}
            type="checkbox"
            checked={valeurs.dateFinNecessaire}
            onChange={(e) => onChange("dateFinNecessaire", e.target.checked)}
          />
          {tr("tarifs.optionDateFin")}
        </label>
        <label className={checkboxLigne}>
          <input
            id={`${idPrefix}-remiseActive`}
            type="checkbox"
            checked={valeurs.remiseActive}
            onChange={(e) => onChange("remiseActive", e.target.checked)}
          />
          {tr("tarifs.optionRemise")}
        </label>
        <label className={checkboxLigne}>
          <input
            id={`${idPrefix}-montantNegociable`}
            type="checkbox"
            checked={valeurs.montantNegociable}
            onChange={(e) => onChange("montantNegociable", e.target.checked)}
          />
          {tr("tarifs.optionNegocie")}
        </label>
      </div>
    );
  }

  function ListeRegimes({ regimes, onChange }: ListeRegimesProps) {
    return (
      <div>
        <label className={labelClass}>{tr("tarifs.regimesProposes")}</label>
        <div className="space-y-2">
          {regimes.map((r, i) => (
            <div key={i} className="flex gap-2">
              <input
                value={r}
                onChange={(e) => {
                  const copie = [...regimes];
                  copie[i] = e.target.value;
                  onChange(copie);
                }}
                placeholder={tr("tarifs.regimesExemple")}
                className={champClass}
              />
              {regimes.length > 1 && (
                <button
                  type="button"
                  onClick={() => onChange(regimes.filter((_, idx) => idx !== i))}
                  className="rounded-lg border border-ink/15 px-3 text-ink transition hover:bg-paper"
                  title={tr("tarifs.retirerRegime")}
                  aria-label={tr("tarifs.retirerRegime")}
                >
                  −
                </button>
              )}
              {i === regimes.length - 1 && (
                <button
                  type="button"
                  onClick={() => onChange([...regimes, ""])}
                  className="rounded-lg border border-accent px-3 text-accent transition hover:bg-accent/10"
                  title={tr("tarifs.ajouterRegime")}
                  aria-label={tr("tarifs.ajouterRegime")}
                >
                  +
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 sm:py-10">
      <div className="mx-auto max-w-3xl">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <h1
            className="text-2xl text-ink sm:text-3xl"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {tr("tarifs.titre")}
          </h1>
          <button
            onClick={() => setAfficherFormulaire(!afficherFormulaire)}
            className="rounded-lg bg-accent px-5 py-2.5 text-sm font-medium text-white transition hover:bg-accent-hover"
          >
            {afficherFormulaire ? tr("commun.annuler") : tr("tarifs.nouvelleOffre")}
          </button>
        </div>

        {message && (
          <p className="mb-4 rounded-lg bg-accent/10 px-3 py-2.5 text-sm text-accent">
            {message}
          </p>
        )}
        {erreur && (
          <p className="mb-4 rounded-lg bg-error/10 px-3 py-2.5 text-sm text-error">
            {erreur}
          </p>
        )}

        {afficherFormulaire && (
          <form
            onSubmit={handleCreer}
            // Pas de contrôle du navigateur sur le prix : les flèches font ±1 000,
            // mais un prix comme 65 500 doit rester accepté
            noValidate
            className="mb-6 space-y-3 rounded-2xl border border-ink/10 bg-white p-6 shadow-sm"
          >
            <label className={labelClass}>{tr("facture.service")}</label>
            <input
              value={form.service}
              onChange={(e) => setForm({ ...form, service: e.target.value })}
              placeholder={tr("tarifs.serviceExemple")}
              list="liste-services"
              className={champClass}
            />
            <datalist id="liste-services">
              {servicesExistants.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
            <p className="text-xs text-ink-soft">
              {tr("tarifs.serviceAide")}
            </p>

            {form.regimeActif && (
              // Appelé comme une fonction (et non <ListeRegimes />) : sinon React
              // recrée le champ à chaque lettre tapée et on ne peut taper qu'un caractère
              ListeRegimes({
                regimes: form.regimes,
                onChange: (regimes) => setForm({ ...form, regimes }),
              })
            )}

            {!form.montantNegociable && (
              <>
                <label className={labelClass}>{tr("tarifs.prixFcfa")}</label>
                {/* Les flèches du champ ajoutent ou retirent 1 000 F */}
                <input
                  type="number"
                  step={1000}
                  min={0}
                  value={form.prix}
                  onChange={(e) => setForm({ ...form, prix: e.target.value })}
                  className={champClass}
                />
              </>
            )}

            {!form.dateFinNecessaire && (
              <>
                <label className={labelClass}>{tr("tarifs.dureeFormation")}</label>
                <input
                  type="number"
                  value={form.dureeJours}
                  onChange={(e) => setForm({ ...form, dureeJours: e.target.value })}
                  className={champClass}
                />
              </>
            )}

            {BlocOptions({
              valeurs: form,
              idPrefix: "creation",
              onChange: (champ, valeur) => setForm({ ...form, [champ]: valeur }),
            })}

            <button
              type="submit"
              disabled={envoiEnCours}
              className="w-full rounded-lg bg-accent py-2.5 font-medium text-white transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60 hover:bg-accent-hover"
            >
              {envoiEnCours ? tr("tarifs.creation") : tr("tarifs.creerOffre")}
            </button>
          </form>
        )}

        {chargement && <p className="text-sm text-ink-soft">{tr("commun.chargement")}</p>}

        <div className="overflow-x-auto rounded-2xl border border-ink/10 bg-white shadow-sm">
          <table className="w-full min-w-[700px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-ink/10 bg-paper text-left text-ink-soft">
                <th className="px-4 py-3 font-medium">{tr("facture.service")}</th>
                <th className="px-4 py-3 font-medium">{tr("tarifs.regimes")}</th>
                <th className="px-4 py-3 font-medium">{tr("tarifs.prix")}</th>
                <th className="px-4 py-3 font-medium">{tr("tarifs.duree")}</th>
                <th className="px-4 py-3 font-medium">{tr("candidats.statut")}</th>
                <th className="px-4 py-3 font-medium">{tr("candidats.action")}</th>
              </tr>
            </thead>
            <tbody>
             {pages.elements.map((t) => (
                <Fragment key={t._id}>
                  <tr className="border-b border-ink/5">
                    <td className="px-4 py-3 font-medium text-ink">{formaterNomService(t.service)}</td>
                    <td className="px-4 py-3">{t.regimes && t.regimes.length > 0 ? t.regimes.join(", ") : "—"}</td>
                    <td className="px-4 py-3">
                      {t.montantNegociable
                        ? tr("tarifs.negocie")
                        : `${(t.prix ?? 0).toLocaleString(locale)} FCFA`}
                    </td>
                    <td className="px-4 py-3">
                      {t.dateFinNecessaire
                        ? tr("tarifs.manuelle")
                        : tr("tarifs.nJours", { n: t.dureeJours ?? 0 })}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={
                          t.actif
                            ? "rounded-full bg-accent/10 px-3 py-1 text-xs font-medium text-accent"
                            : "rounded-full bg-error/10 px-3 py-1 text-xs font-medium text-error"
                        }
                      >
                        {t.actif ? tr("tarifs.active") : tr("tarifs.inactive")}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-3">
                        <button
                          onClick={() => ouvrirEdition(t)}
                          className="font-medium text-seal hover:underline"
                        >
                          {tr("candidats.modifier")}
                        </button>
                        <button
                          onClick={() => supprimerTarif(t)}
                          disabled={suppressionEnCours === t._id}
                          className="font-medium text-error hover:underline disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          {suppressionEnCours === t._id ? tr("candidats.suppressionEnCours") : tr("candidats.supprimer")}
                        </button>
                      </div>
                    </td>
                  </tr>

                  {ligneEnEdition === t._id && (
                    <tr className="border-b border-ink/5 bg-accent/5">
                      <td colSpan={6} className="space-y-3 px-4 py-4">
                        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                          <div>
                            <label className="mb-1 block text-xs font-medium text-ink-soft">
                              {tr("facture.service")}
                            </label>
                            <input
                              value={editForm.service}
                              onChange={(e) =>
                                setEditForm({ ...editForm, service: e.target.value })
                              }
                              list="liste-services"
                              className={`${champClass} bg-white`}
                            />
                          </div>
                          {!editForm.montantNegociable && (
                            <div>
                              <label className="mb-1 block text-xs font-medium text-ink-soft">
                                {tr("tarifs.prixFcfa")}
                              </label>
                              <input
                                type="number"
                                step={1000}
                                min={0}
                                value={editForm.prix}
                                onChange={(e) =>
                                  setEditForm({ ...editForm, prix: e.target.value })
                                }
                                className={`${champClass} bg-white`}
                              />
                            </div>
                          )}
                          {!editForm.dateFinNecessaire && (
                            <div>
                              <label className="mb-1 block text-xs font-medium text-ink-soft">
                                {tr("tarifs.dureeJours")}
                              </label>
                              <input
                                type="number"
                                value={editForm.dureeJours}
                                onChange={(e) =>
                                  setEditForm({ ...editForm, dureeJours: e.target.value })
                                }
                                className={`${champClass} bg-white`}
                              />
                            </div>
                          )}
                          <div>
                            <label className="mb-1 block text-xs font-medium text-ink-soft">
                              {tr("candidats.statut")}
                            </label>
                            <select
                              value={editForm.actif ? "actif" : "inactif"}
                              onChange={(e) =>
                                setEditForm({ ...editForm, actif: e.target.value === "actif" })
                              }
                              className={`${champClass} bg-white`}
                            >
                              <option value="actif">{tr("tarifs.active")}</option>
                              <option value="inactif">{tr("tarifs.inactive")}</option>
                            </select>
                          </div>
                        </div>

                        {editForm.regimeActif && (
                          ListeRegimes({
                            regimes: editForm.regimes,
                            onChange: (regimes) => setEditForm({ ...editForm, regimes }),
                          })
                        )}

                        {BlocOptions({
                          valeurs: editForm,
                          idPrefix: `edition-${t._id}`,
                          onChange: (champ, valeur) => setEditForm({ ...editForm, [champ]: valeur }),
                        })}

                        <div className="flex gap-2">
                          <button
                            onClick={() => enregistrerModification(t._id)}
                            disabled={enregistrementEnCours}
                            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-60"
                          >
                            {enregistrementEnCours ? tr("facture.enregistrementCourt") : tr("commun.enregistrer")}
                          </button>
                          <button
                            onClick={() => setLigneEnEdition(null)}
                            disabled={enregistrementEnCours}
                            className="rounded-lg border border-ink/15 px-4 py-2 text-sm font-medium text-ink transition hover:bg-paper disabled:cursor-not-allowed disabled:opacity-60"
                          >
                            {tr("commun.annuler")}
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
              </Fragment>
              ))}
            </tbody>
          </table>

          {tarifs.length === 0 && !chargement && (
            <p className="px-4 py-8 text-center text-ink-soft">
              {tr("tarifs.aucune")}
            </p>
          )}
        </div>

        <Pagination
          page={pages.page}
          totalPages={pages.totalPages}
          onChange={pages.setPage}
          texte={tr("tarifs.pagination", { page: pages.page, total: pages.totalPages, n: pages.total })}
          precedent={tr("candidats.precedent")}
          suivant={tr("candidats.suivant")}
        />
      </div>
    </div>
  );
}