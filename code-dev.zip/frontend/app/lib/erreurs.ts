// Traduction des messages envoyés par le serveur.
// Le serveur répond toujours en français ; si l'interface est en anglais,
// on remplace le message par sa version anglaise. Un message inconnu reste tel quel.

const MESSAGES_EN: Record<string, string> = {
  // Connexion et compte
  "Email ou mot de passe incorrect": "Incorrect email or password",
  "Ce centre est suspendu. Contacte HREFF pour le réactiver.":
    "This centre is suspended. Contact HREFF to reactivate it.",
  "Email invalide": "Invalid email",
  "Le mot de passe est obligatoire": "Password is required",
  "Le mot de passe doit contenir au moins 6 caractères": "The password must have at least 6 characters",
  "Ce mot de passe a déjà été utilisé. Choisis-en un différent.":
    "This password has already been used. Choose a different one.",
  "Le nouveau mot de passe est obligatoire": "The new password is required",
  "Le code est obligatoire": "The code is required",
  "Le code doit contenir 6 chiffres": "The code must have 6 digits",
  "Code de vérification invalide": "Invalid verification code",
  "Code de réinitialisation invalide": "Invalid reset code",
  "Ce code a expiré, demande-en un nouveau": "This code has expired, request a new one",
  "Ce code a expiré, refais une demande": "This code has expired, make a new request",
  "Cet email est déjà vérifié": "This email is already verified",
  "Email vérifié avec succès": "Email verified",
  "Un nouveau code de vérification a été envoyé": "A new verification code has been sent",
  "Si cet email existe, un code de réinitialisation a été envoyé":
    "If this email exists, a reset code has been sent",
  "Mot de passe réinitialisé avec succès": "Password reset",
  "Déconnecté avec succès": "Logged out",

  // Centre
  "Centre introuvable": "Centre not found",
  "Un centre porte déjà ce nom": "A centre already has this name",
  "Le nom du centre est obligatoire": "The centre name is required",
  "Le nom du centre ne peut pas être vide": "The centre name cannot be empty",
  "Cette action nécessite d'être rattaché à un centre":
    "This action requires being linked to a centre",
  "Mode de paiement invalide": "Invalid payment method",
  "Ce mode de paiement n'est pas accepté par le centre (voir Paramètres → Paiements)":
    "This payment method is not accepted by the centre (see Settings → Payments)",

  // Utilisateurs
  "Utilisateur introuvable": "User not found",
  "Un utilisateur avec cet email existe déjà": "A user with this email already exists",
  "Un compte existe déjà avec cet email": "An account already exists with this email",
  "Rôle invalide": "Invalid role",
  "Le nom est obligatoire": "The name is required",
  "Le prénom est obligatoire": "The first name is required",
  "Le téléphone est obligatoire": "The phone number is required",

  // Candidats et factures
  "Candidat introuvable": "Candidate not found",
  "Inscription introuvable": "Registration not found",
  "L'identifiant du candidat est obligatoire": "The candidate ID is required",
  "Le service est obligatoire": "The service is required",
  "Le régime est obligatoire pour ce service": "The schedule is required for this service",
  "Le montant négocié est obligatoire pour ce service":
    "The negotiated amount is required for this service",
  "La date de fin est obligatoire pour ce service": "The end date is required for this service",
  "Date de fin invalide": "Invalid end date",
  "Date de début du test invalide": "Invalid test start date",
  "Le montant payé ne peut pas être négatif": "The amount paid cannot be negative",
  "Le montant payé ne peut pas dépasser le montant total":
    "The amount paid cannot exceed the total amount",
  "La remise ne peut pas être négative": "The discount cannot be negative",
  "La remise ne peut pas dépasser le montant total": "The discount cannot exceed the total amount",
  "Le montant du paiement doit être positif": "The payment amount must be positive",
  "Le montant doit être positif": "The amount must be positive",
  "Ce paiement dépasserait le montant total dû": "This payment would exceed the total amount due",
  "La raison de la modification est obligatoire": "The reason for the change is required",
  'Le champ "facturé par" est obligatoire': 'The "invoiced by" field is required',
  "La facture n'a pas pu être générée ou stockée": "The invoice could not be generated or stored",
  "Impossible de générer le lien de la facture (vérifie la configuration AWS)":
    "Unable to create the invoice link (check the AWS settings)",
  "Aucune offre active n'est configurée pour ce service. Va dans la page Tarifs pour créer ou activer cette offre.":
    "No active offer is set up for this service. Go to the Prices page to create or activate it.",

  // Tarifs
  "Offre introuvable": "Offer not found",
  "Offre supprimée": "Offer deleted",
  "Le prix ne peut pas être négatif": "The price cannot be negative",
  "Le prix est obligatoire (sauf si le montant est négociable)":
    "The price is required (unless the amount is negotiable)",
  "La durée ne peut pas être négative": "The duration cannot be negative",
  "La durée en jours est obligatoire (sauf si la date de fin est saisie manuellement)":
    "The duration in days is required (unless the end date is entered manually)",
  "Il faut au moins un régime": "At least one schedule is required",

  // Corrections et export
  "Seul l'administrateur peut modifier les montants, le service et le paiement d'une facture":
    "Only the administrator can change the amounts, the service and the payment of an invoice",
  "Ce candidat a des factures : il ne peut pas être supprimé":
    "This candidate has invoices: they cannot be deleted",
  "Choisis une date de début et une date de fin": "Choose a start date and an end date",
  "La date de début doit être avant la date de fin": "The start date must be before the end date",

  // Abonnement et paiement CamPay
  "L'abonnement du centre a expiré : plus de nouvelle facture. L'administrateur doit le renouveler (menu Abonnement).":
    "The centre's subscription has expired: no new invoices. The administrator must renew it (Subscription menu).",
  "L'abonnement du centre a expiré : renouvelle-le (menu Abonnement) pour créer un compte.":
    "The centre's subscription has expired: renew it (Subscription menu) to create an account.",
  "Numéro de téléphone invalide (exemple : 6 90 00 00 00)": "Invalid phone number (example: 6 90 00 00 00)",
  "Numéro de téléphone invalide": "Invalid phone number",
  "Seuls les numéros MTN et Orange sont acceptés": "Only MTN and Orange numbers are accepted",
  "Montant invalide": "Invalid amount",
  "Solde insuffisant": "Insufficient balance",
  "CamPay a refusé la demande de paiement, réessaie": "CamPay refused the payment request, try again",
  "Le serveur n'arrive pas à joindre CamPay, réessaie": "The server cannot reach CamPay, try again",
  "Le paiement en ligne n'est pas encore configuré": "Online payment is not set up yet",
  "Connexion à CamPay refusée : vérifie CAMPAY_USERNAME et CAMPAY_PASSWORD":
    "CamPay login refused: check CAMPAY_USERNAME and CAMPAY_PASSWORD",
  "CamPay n'a pas renvoyé de lien de paiement": "CamPay did not return a payment link",
  "Le plan Gratuit ne se paie pas": "The Free plan is not paid",
  "Plan inconnu": "Unknown plan",
  "Ce plan ne se paie pas à l'année": "This plan cannot be paid yearly",
  "Ce plan ne se paie pas au mois": "This plan cannot be paid monthly",
  "Paiement introuvable": "Payment not found",
  "Choisis un plan": "Choose a plan",
  "Durée invalide (mensuel ou annuel)": "Invalid duration (monthly or yearly)",
  "Paiement refusé ou annulé": "Payment refused or cancelled",
  "Montant reçu incorrect": "Incorrect amount received",
  "Demande refusée": "Request refused",
  "Indique un nombre de factures par mois": "Enter a number of invoices per month",
  "Indique un nombre de comptes": "Enter a number of accounts",
  "Nombre de factures trop grand": "Number of invoices too large",
  "Nombre de comptes trop grand": "Number of accounts too large",

  // Vérification de la caisse
  "Ce lien ne correspond à aucune caisse.": "This link does not match any cash register.",
  "Ce lien a expiré. Retrouve cette caisse sur ton Accueil dans l'application.":
    "This link has expired. Find this cash register on your Home page in the app.",
  "Caisse introuvable": "Cash register not found",
  "Choix invalide": "Invalid choice",
  "Le message est vide": "The message is empty",
  "Le message est trop long (1000 caractères maximum)": "The message is too long (1000 characters maximum)",
  "Cette caisse n'est pas la tienne.": "This cash register is not yours.",
  "Aucune question n'attend ta réponse.": "No question is waiting for your answer.",

  // Paiement CamPay des candidats et retraits
  "Indique le montant que le candidat va payer": "Enter the amount the candidate will pay",
  "Facture introuvable": "Invoice not found",
  "Retrait introuvable": "Withdrawal not found",
  "Ce retrait a déjà été traité": "This withdrawal has already been processed",
  "Le paiement Mobile Money direct n'est pas activé pour ce centre (voir Paramètres → Paiements)":
    "Direct Mobile Money payment is not enabled for this centre (see Settings → Payments)",
  "Un paiement direct se lance avec le mode « Mobile Money (direct) » du formulaire":
    "A direct payment is started with the “Mobile Money (direct)” method of the form",
  "CamPay n'a pas confirmé l'envoi": "CamPay did not confirm the transfer",
};

// Messages qui contiennent une valeur (montant, nom, nombre)
const MODELES_EN: [RegExp, (...valeurs: string[]) => string][] = [
  [/^Le retrait minimum est de (.+) FCFA$/, (montant) => `The minimum withdrawal is ${montant} FCFA`],
  [
    /^Solde insuffisant : tu peux retirer au plus (.+) FCFA$/,
    (montant) => `Insufficient balance: you can withdraw at most ${montant} FCFA`,
  ],
  [
    /^Le régime "(.+)" n'existe pas pour ce service\.$/,
    (regime) => `The schedule "${regime}" does not exist for this service.`,
  ],
  [
    /^Le montant payé doit être supérieur à (.+) FCFA pour enregistrer une inscription$/,
    (min) => `The amount paid must be more than ${min} FCFA to save a registration`,
  ],
  [
    /^Le montant payé doit être supérieur à (.+) FCFA$/,
    (min) => `The amount paid must be more than ${min} FCFA`,
  ],
  [
    /^Ce service coûte (.+) FCFA \(moins de (.+) FCFA\) : il doit être payé intégralement à l'inscription$/,
    (prix, min) =>
      `This service costs ${prix} FCFA (less than ${min} FCFA): it must be paid in full at registration`,
  ],
  [
    /^Ce service coûte (.+) FCFA : il doit être payé intégralement$/,
    (prix) => `This service costs ${prix} FCFA: it must be paid in full`,
  ],
  [
    /^Ce service a déjà été utilisé sur (\d+) facture\(s\) : il a été désactivé au lieu d'être supprimé\.$/,
    (nombre) =>
      `This service has already been used on ${nombre} invoice(s): it was deactivated instead of deleted.`,
  ],
  [
    /^Limite de (\d+) factures ce mois atteinte \(plan (.+)\)\. L'administrateur peut passer à un plan supérieur \(menu Abonnement\)\.$/,
    (limite, plan) =>
      `${limite}-invoice monthly limit reached (${plan} plan). The administrator can upgrade (Subscription menu).`,
  ],
  [
    /^Les (\d+) factures gratuites sont utilisées\. L'administrateur doit choisir un plan payant \(menu Abonnement\)\.$/,
    (limite) => `The ${limite} free invoices are used up. The administrator must choose a paid plan (Subscription menu).`,
  ],
  [
    /^Limite de (\d+) comptes atteinte \(plan (.+)\)\. Passe à un plan supérieur \(menu Abonnement\)\.$/,
    (limite, plan) => `${limite}-account limit reached (${plan} plan). Upgrade your plan (Subscription menu).`,
  ],
];

function langueChoisie(): string {
  if (typeof window === "undefined") return "fr";
  try {
    return localStorage.getItem("langue") ?? "fr";
  } catch {
    return "fr";
  }
}

// Traduit un seul message (si l'interface est en anglais)
export function traduireMessageServeur(message: string): string {
  if (langueChoisie() !== "en" || typeof message !== "string") return message;
  // Les espaces spéciaux des montants (65 000) deviennent des espaces normaux
  const texte = message.replace(/[  ]/g, " ").trim();
  if (MESSAGES_EN[texte]) return MESSAGES_EN[texte];
  for (const [modele, traduire] of MODELES_EN) {
    const trouve = texte.match(modele);
    if (trouve) return traduire(...trouve.slice(1));
  }
  return message;
}

// Traduit le champ "message" d'une réponse (texte seul ou liste de textes)
export function traduireReponse<T>(data: T): T {
  if (!data || typeof data !== "object") return data;
  const objet = data as Record<string, unknown>;
  if (typeof objet.message === "string") {
    return { ...objet, message: traduireMessageServeur(objet.message) } as T;
  }
  if (Array.isArray(objet.message)) {
    return {
      ...objet,
      message: objet.message.map((m) => (typeof m === "string" ? traduireMessageServeur(m) : m)),
    } as T;
  }
  return data;
}