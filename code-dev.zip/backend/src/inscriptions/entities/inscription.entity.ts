export class Inscription {}
