export class Candidat {}
